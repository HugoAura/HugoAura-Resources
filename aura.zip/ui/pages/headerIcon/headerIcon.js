global.__HUGO_AURA_UI_FUNCTIONS__.headerIcon = {
  showAuraConfig: () => {
    window.__HUGO_AURA_LOADER__["Aura.UI.Assistant.Config"].active = true;
  },
};
